import React from 'react';
import {View, Text} from 'react-native';


const HomePage = () => {

  return (

    <View style={{flex:1, alignItems:'center', justifyContent:'center'}}> 

    <text> PUC Minas </text>
    
    
    </View>

  );

  }

export default HomePage; 